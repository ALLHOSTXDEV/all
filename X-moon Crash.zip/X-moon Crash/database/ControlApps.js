module.exports = {
  tokens: "8276896094:AAGiLdn1ii6JRbPdJL-ajmKi67FS-fUi0Lc", 
  owner: "7568537295", 
  port: "2105", // Ini Wajib Jangan Diubah
  ipvps: "http://mypanellku.naell.my.id.allhost.my.id" // Jangan Diubah Nanti Eror!!
};